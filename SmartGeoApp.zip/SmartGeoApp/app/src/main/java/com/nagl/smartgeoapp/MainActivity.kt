package com.nagl.smartgeoapp

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.nagl.smartgeoapp.interfaces.ITopPanel

class MainActivity : AppCompatActivity(), ITopPanel {

    override var panelContext: Activity = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        createPanel()

    }

    private fun createPanel() {
        initTopPanel(getString(R.string.str_main_activity_title_text))
    }

    override fun actionClick() {
        // TODO: help
    }
}