package com.nagl.smartgeoapp.interfaces

import android.app.Activity

interface IPanel {
    var panelContext: Activity
}